/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_309(unsigned *p)
{
    *p = 2425378890U;
}

unsigned getval_223()
{
    return 138199896U;
}

unsigned addval_111(unsigned x)
{
    return x + 3626594681U;
}

unsigned getval_133()
{
    return 3347662884U;
}

void setval_448(unsigned *p)
{
    *p = 3267856712U;
}

void setval_113(unsigned *p)
{
    *p = 3284633930U;
}

unsigned addval_216(unsigned x)
{
    return x + 3347662991U;
}

unsigned addval_392(unsigned x)
{
    return x + 3243806734U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_399()
{
    return 3385115273U;
}

unsigned getval_174()
{
    return 3374367369U;
}

unsigned addval_195(unsigned x)
{
    return x + 3221799565U;
}

unsigned addval_393(unsigned x)
{
    return x + 3286270280U;
}

unsigned getval_371()
{
    return 3281309321U;
}

void setval_343(unsigned *p)
{
    *p = 2446231891U;
}

unsigned getval_460()
{
    return 3281047177U;
}

unsigned getval_210()
{
    return 3252717896U;
}

void setval_130(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_184(unsigned x)
{
    return x + 3281044105U;
}

unsigned addval_131(unsigned x)
{
    return x + 3286272328U;
}

void setval_421(unsigned *p)
{
    *p = 3525889673U;
}

unsigned getval_248()
{
    return 3284310322U;
}

void setval_426(unsigned *p)
{
    *p = 3677933965U;
}

unsigned addval_107(unsigned x)
{
    return x + 3525889673U;
}

void setval_432(unsigned *p)
{
    *p = 3229929097U;
}

unsigned addval_125(unsigned x)
{
    return x + 3229929869U;
}

unsigned getval_304()
{
    return 3515472179U;
}

unsigned addval_193(unsigned x)
{
    return x + 3224424073U;
}

unsigned addval_402(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_218()
{
    return 3525890441U;
}

unsigned addval_401(unsigned x)
{
    return x + 2425409993U;
}

unsigned getval_409()
{
    return 2464188744U;
}

unsigned getval_391()
{
    return 1321456008U;
}

void setval_468(unsigned *p)
{
    *p = 3286288712U;
}

unsigned addval_335(unsigned x)
{
    return x + 2425406091U;
}

unsigned getval_221()
{
    return 3531915945U;
}

unsigned getval_303()
{
    return 3281047817U;
}

unsigned addval_103(unsigned x)
{
    return x + 3515470482U;
}

unsigned addval_141(unsigned x)
{
    return x + 3536113289U;
}

unsigned getval_380()
{
    return 3375415945U;
}

unsigned addval_445(unsigned x)
{
    return x + 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
